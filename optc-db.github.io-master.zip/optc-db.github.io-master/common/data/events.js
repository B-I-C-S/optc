window.events = {
    879: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    880: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    900: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    901: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    989: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1036: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1037: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1243: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1244: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1291: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1292: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1305: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1306: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1313: {
        onInsertion: function($scope) {
            if (++$scope.options.strOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [STR] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.strOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [STR] orbs support.' });
        }
    },
    1314: {
        onInsertion: function($scope) {
            if (++$scope.options.strOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [STR] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.strOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [STR] orbs support.' });
        }
    },
    1472: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    1473: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    1523: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1524: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1531: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    1532: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    1609: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    1610: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    1651: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    1652: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    1901: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1902: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    1940: {
        onInsertion: function($scope) {
            if (++$scope.options.strOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [STR] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.strOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [STR] orbs support.' });
        }
    },
    1941: {
        onInsertion: function($scope) {
            if (++$scope.options.strOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [STR] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.strOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [STR] orbs support.' });
        }
    },
    2012: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2013: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2040: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled == 0)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        }
    },
    2041: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled == 0)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        }
    },
    2108: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled == 0)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        }
    },
    2109: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled == 0)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        }
    },
    2232: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2233: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2234: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2241: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    2242: {
        onInsertion: function($scope) {
            if (++$scope.options.gOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [G] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.gOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [G] orbs support.' });
        }
    },
    2500: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2373: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2374: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2375: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2476: {
        onInsertion: function($scope) {
            if (++$scope.options.dexOrbsEnabled == 1){}
            if (++$scope.options.intOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [DEX] and [INT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.dexOrbsEnabled === 0){}
            if (--$scope.options.intOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [DEX] and [INT] orbs support.' });
        }
    },
    2477: {
        onInsertion: function($scope) {
            if (++$scope.options.dexOrbsEnabled == 1){}
            if (++$scope.options.intOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [DEX] and [INT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.dexOrbsEnabled === 0){}
            if (--$scope.options.intOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [DEX] and [INT] orbs support.' });
        }
    },
    2525: {
        onInsertion: function($scope) {
            if (++$scope.options.intOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [INT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.intOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [INT] orbs support.' });
        }
    },
    2631: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    2801: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    2802: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    2803: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    2804: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5052: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5053: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5054: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5055: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5056: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5057: {
        onInsertion: function($scope) {
            if (++$scope.options.meatOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [MEAT] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.meatOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [MEAT] orbs support.' });
        }
    },
    5168: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5169: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5170: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5171: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5172: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5173: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5174: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5175: {
        onInsertion: function($scope) {
            if (++$scope.options.rainbowOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [RAINBOW] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.rainbowOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [RAINBOW] orbs support.' });
        }
    },
    5191: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5192: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5193: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5194: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5195: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5196: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5197: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
    5198: {
        onInsertion: function($scope) {
            if (++$scope.options.wanoOrbsEnabled == 1)
                $scope.notify({ text: 'Enabling [WANO] orbs support.' });
        },
        onRemoval: function($scope) {
            if (--$scope.options.wanoOrbsEnabled === 0)
                $scope.notify({ text: 'Disabling [WANO] orbs support.' });
        }
    },
};
