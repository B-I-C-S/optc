# OPTC Calculator
This is a calculator for the mobile game One Piece Treasure Cruise. More features will be added as they are requested. Shoot me a message on reddit if you want something else added.

Changelog can be viewed [here](https://github.com/cyung/optc/commits/gh-pages).

This is my first project done using AngularJS and I'm learning along the way, but I've made sure to follow the [Angular Style Guide](https://github.com/johnpapa/angular-styleguide) to make for easy reading.
