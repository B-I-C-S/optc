angular.module('app')
	.controller('NavbarCtrl', function($scope) {
		$scope.isCollapsed = true;
	});