# optc-db.github.io

The Continuation of the highly loved and apreciated OPTC Database.

This is a Database for all things One Piece Treasure Cruise, including Stats, Drops, Sockets and a Damage Calculator.

This project is written in html and js, using angular, bootstrap and jquery.

It is hosted on github pages, although you can just download it and run a local copy.

# Team

* Mondfischer - Took over the Project and responsible for adding features and data
* Zeenigami - Joined shorty after and helps out with data and features (And usually adds the newest Units)
* xfts - The newest member for fact checking and everything concerning translations
* Everyone else on Discord/Reddit/Github etc that reports errors and wrong data

# Installation

Just download it and run it in some kind of Live preview or via xampp. Or better yet access it via http://optc-db.github.io

Keep in mind though that the images are not hosted here, but instead linked from the offical site. So you would need an internet connection to see them.

# Contact
 You can reach us on Discord @Mondfischer and @Zeenigami and on Reddit as Mondfischer and Zee_n1
 
 The site also has a google contact form, you can also open an Issue on here.
 
# License
 
 GNU General Public License
 
 It's also in the Project named LICENSE.md.
